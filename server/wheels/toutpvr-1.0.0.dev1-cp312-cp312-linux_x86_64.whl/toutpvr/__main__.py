"""Point d'entrée ``python -m toutpvr``."""
from toutpvr.cli import main
raise SystemExit(main())
